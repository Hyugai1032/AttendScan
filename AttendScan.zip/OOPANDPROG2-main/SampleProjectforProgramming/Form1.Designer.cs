﻿namespace SampleProjectforProgramming
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.lblRegistration = new System.Windows.Forms.Label();
            this.guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.button5 = new System.Windows.Forms.Button();
            this.gaddStudent = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.gtimeinout = new Guna.UI2.WinForms.Guna2Button();
            this.label2 = new System.Windows.Forms.Label();
            this.grecords = new Guna.UI2.WinForms.Guna2Button();
            this.gprint = new Guna.UI2.WinForms.Guna2Button();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.guna2Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.guna2GradientPanel1.SuspendLayout();
            this.guna2GradientPanel2.SuspendLayout();
            this.guna2GradientPanel3.SuspendLayout();
            this.guna2Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.BackColor = System.Drawing.Color.SandyBrown;
            this.guna2Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.guna2Panel2.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            this.guna2Panel2.Controls.Add(this.label11);
            this.guna2Panel2.Controls.Add(this.button1);
            this.guna2Panel2.Controls.Add(this.button2);
            this.guna2Panel2.Controls.Add(this.button3);
            this.guna2Panel2.Controls.Add(this.pictureBox1);
            this.guna2Panel2.CustomBorderColor = System.Drawing.Color.Green;
            this.guna2Panel2.Location = new System.Drawing.Point(-9, -2);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1317, 90);
            this.guna2Panel2.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(47, 140);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(152, 45);
            this.button1.TabIndex = 1;
            this.button1.Text = "Student";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(47, 286);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(152, 39);
            this.button2.TabIndex = 3;
            this.button2.Text = "Records";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(47, 213);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(152, 44);
            this.button3.TabIndex = 2;
            this.button3.Text = "Time In/Out";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::SampleProjectforProgramming.Properties.Resources._440979595_1825340057973007_1015642796755802723_n_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(396, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(129, 90);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.Color.Khaki;
            this.guna2GradientPanel1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.guna2GradientPanel1.Controls.Add(this.lblRegistration);
            this.guna2GradientPanel1.Location = new System.Drawing.Point(304, 155);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(200, 100);
            this.guna2GradientPanel1.TabIndex = 7;
            // 
            // lblRegistration
            // 
            this.lblRegistration.AutoSize = true;
            this.lblRegistration.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegistration.Location = new System.Drawing.Point(3, 43);
            this.lblRegistration.Name = "lblRegistration";
            this.lblRegistration.Size = new System.Drawing.Size(124, 21);
            this.lblRegistration.TabIndex = 1;
            this.lblRegistration.Text = "Total Student:";
            this.lblRegistration.Click += new System.EventHandler(this.lblRegistration_Click);
            // 
            // guna2GradientPanel2
            // 
            this.guna2GradientPanel2.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.guna2GradientPanel2.Controls.Add(this.label4);
            this.guna2GradientPanel2.Location = new System.Drawing.Point(590, 155);
            this.guna2GradientPanel2.Name = "guna2GradientPanel2";
            this.guna2GradientPanel2.Size = new System.Drawing.Size(200, 100);
            this.guna2GradientPanel2.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 21);
            this.label4.TabIndex = 2;
            this.label4.Text = "Total Student:";
            // 
            // guna2GradientPanel3
            // 
            this.guna2GradientPanel3.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.guna2GradientPanel3.Controls.Add(this.label5);
            this.guna2GradientPanel3.Location = new System.Drawing.Point(920, 155);
            this.guna2GradientPanel3.Name = "guna2GradientPanel3";
            this.guna2GradientPanel3.Size = new System.Drawing.Size(200, 100);
            this.guna2GradientPanel3.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 21);
            this.label5.TabIndex = 3;
            this.label5.Text = "Total Student:";
            // 
            // guna2Button1
            // 
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BorderRadius = 20;
            this.guna2Button1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.BurlyWood;
            this.guna2Button1.Font = new System.Drawing.Font("Tahoma", 11F);
            this.guna2Button1.ForeColor = System.Drawing.Color.Black;
            this.guna2Button1.Location = new System.Drawing.Point(32, 186);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(152, 42);
            this.guna2Button1.TabIndex = 9;
            this.guna2Button1.Text = "Dashboard";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.SandyBrown;
            this.button5.Location = new System.Drawing.Point(60, 611);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(98, 49);
            this.button5.TabIndex = 5;
            this.button5.Text = "LogOut";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // gaddStudent
            // 
            this.gaddStudent.AutoRoundedCorners = true;
            this.gaddStudent.BorderRadius = 20;
            this.gaddStudent.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.gaddStudent.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gaddStudent.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gaddStudent.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gaddStudent.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gaddStudent.FillColor = System.Drawing.Color.BurlyWood;
            this.gaddStudent.Font = new System.Drawing.Font("Tahoma", 11F);
            this.gaddStudent.ForeColor = System.Drawing.Color.Black;
            this.gaddStudent.Location = new System.Drawing.Point(31, 273);
            this.gaddStudent.Name = "gaddStudent";
            this.gaddStudent.Size = new System.Drawing.Size(152, 42);
            this.gaddStudent.TabIndex = 10;
            this.gaddStudent.Text = "Add Student";
            this.gaddStudent.Click += new System.EventHandler(this.gaddStudent_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 14F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(25, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 32);
            this.label1.TabIndex = 6;
            this.label1.Text = "Hello";
            // 
            // gtimeinout
            // 
            this.gtimeinout.AutoRoundedCorners = true;
            this.gtimeinout.BackColor = System.Drawing.Color.Transparent;
            this.gtimeinout.BorderRadius = 20;
            this.gtimeinout.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.gtimeinout.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gtimeinout.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gtimeinout.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gtimeinout.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gtimeinout.FillColor = System.Drawing.Color.BurlyWood;
            this.gtimeinout.Font = new System.Drawing.Font("Tahoma", 11F);
            this.gtimeinout.ForeColor = System.Drawing.Color.Black;
            this.gtimeinout.Location = new System.Drawing.Point(32, 358);
            this.gtimeinout.Name = "gtimeinout";
            this.gtimeinout.Size = new System.Drawing.Size(152, 42);
            this.gtimeinout.TabIndex = 11;
            this.gtimeinout.Text = "Time In/Out";
            this.gtimeinout.Click += new System.EventHandler(this.gtimeinout_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(78, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 7;
            // 
            // grecords
            // 
            this.grecords.AutoRoundedCorners = true;
            this.grecords.BackColor = System.Drawing.Color.Transparent;
            this.grecords.BorderRadius = 20;
            this.grecords.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.grecords.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.grecords.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.grecords.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.grecords.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.grecords.FillColor = System.Drawing.Color.BurlyWood;
            this.grecords.Font = new System.Drawing.Font("Tahoma", 11F);
            this.grecords.ForeColor = System.Drawing.Color.Black;
            this.grecords.Location = new System.Drawing.Point(30, 446);
            this.grecords.Name = "grecords";
            this.grecords.Size = new System.Drawing.Size(152, 42);
            this.grecords.TabIndex = 12;
            this.grecords.Text = "Records";
            this.grecords.Click += new System.EventHandler(this.grecords_Click);
            // 
            // gprint
            // 
            this.gprint.AutoRoundedCorners = true;
            this.gprint.BorderRadius = 20;
            this.gprint.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.gprint.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gprint.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gprint.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gprint.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gprint.FillColor = System.Drawing.Color.BurlyWood;
            this.gprint.Font = new System.Drawing.Font("Tahoma", 11F);
            this.gprint.ForeColor = System.Drawing.Color.Black;
            this.gprint.Location = new System.Drawing.Point(33, 534);
            this.gprint.Name = "gprint";
            this.gprint.Size = new System.Drawing.Size(152, 42);
            this.gprint.TabIndex = 13;
            this.gprint.Text = "Print";
            this.gprint.Click += new System.EventHandler(this.gprint_Click);
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.BackColor = System.Drawing.Color.LimeGreen;
            this.guna2CustomGradientPanel1.FillColor = System.Drawing.Color.LawnGreen;
            this.guna2CustomGradientPanel1.FillColor2 = System.Drawing.Color.LightGreen;
            this.guna2CustomGradientPanel1.FillColor3 = System.Drawing.Color.Lime;
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(10, 186);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(14, 40);
            this.guna2CustomGradientPanel1.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 14F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(85, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 32);
            this.label3.TabIndex = 15;
            this.label3.Text = "Admin";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.AutoRoundedCorners = true;
            this.guna2Panel1.BackColor = System.Drawing.Color.Bisque;
            this.guna2Panel1.BorderColor = System.Drawing.Color.Gray;
            this.guna2Panel1.BorderRadius = 101;
            this.guna2Panel1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            this.guna2Panel1.Controls.Add(this.label3);
            this.guna2Panel1.Controls.Add(this.guna2CustomGradientPanel1);
            this.guna2Panel1.Controls.Add(this.gprint);
            this.guna2Panel1.Controls.Add(this.grecords);
            this.guna2Panel1.Controls.Add(this.label2);
            this.guna2Panel1.Controls.Add(this.gtimeinout);
            this.guna2Panel1.Controls.Add(this.label1);
            this.guna2Panel1.Controls.Add(this.gaddStudent);
            this.guna2Panel1.Controls.Add(this.button5);
            this.guna2Panel1.Controls.Add(this.guna2Button1);
            this.guna2Panel1.CustomBorderColor = System.Drawing.Color.Green;
            this.guna2Panel1.Location = new System.Drawing.Point(0, -2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(205, 686);
            this.guna2Panel1.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Georgia", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(523, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(270, 56);
            this.label11.TabIndex = 38;
            this.label11.Text = "AttendScan";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(1298, 682);
            this.Controls.Add(this.guna2GradientPanel3);
            this.Controls.Add(this.guna2GradientPanel2);
            this.Controls.Add(this.guna2GradientPanel1);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.guna2GradientPanel1.ResumeLayout(false);
            this.guna2GradientPanel1.PerformLayout();
            this.guna2GradientPanel2.ResumeLayout(false);
            this.guna2GradientPanel2.PerformLayout();
            this.guna2GradientPanel3.ResumeLayout(false);
            this.guna2GradientPanel3.PerformLayout();
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private System.Windows.Forms.Label lblRegistration;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.Button button5;
        private Guna.UI2.WinForms.Guna2Button gaddStudent;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button gtimeinout;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2Button grecords;
        private Guna.UI2.WinForms.Guna2Button gprint;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.Label label11;
    }
}


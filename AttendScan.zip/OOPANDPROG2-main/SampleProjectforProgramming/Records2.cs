﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleProjectforProgramming
{
    public partial class Records2 : Form
    {
        public Records2()
        {
            InitializeComponent();
        }

        private void Records2_Load(object sender, EventArgs e)
        {

        }
    }
}
